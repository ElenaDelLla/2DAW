Los dos efectos introducidos en la canción "Rise TwinsMusic" de la web "bensound" en el enlace https://www.bensound.com/royalty-free-music?tag[]=rise&sort=relevance
por medio del programa "Audacity":

Efecto->Volumen y compresión->Amplificar:

El original estaba en 0,508 db y se actualiza aplicando a 20 db (el efecto se aprecia en que distorsiona y satura el sonido).

Efecto->Tono y tempo->Cambiar velocidad:

El factor multiplicador original estaba en 1,000 y el Porcentaje de cambio a 0,000. Al actualizar el factor multiplicador a 2,000 el Porcentaje de cambio pasa a 100,000

**El programa permite convertir a los formatos .mp3 y .ogg 
  pero para convertir a .acc se ha usado la web de https://convertio.co/es/mp3-aac/ desde .mp3 a .acc**
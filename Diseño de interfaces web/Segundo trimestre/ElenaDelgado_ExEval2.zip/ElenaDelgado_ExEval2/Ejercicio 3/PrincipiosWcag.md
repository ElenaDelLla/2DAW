# ELENA DELGADO LLAMAS

Cambios realizados:

1. Se añade imagen en el aside correspondiente.
2. Se añade un alt (descripcion breve) a la imagen.
3. Se añade un longDesc (descripcion larga) a la imagen ya que es una imagen con bastante contenido e importancia.

Estas modificaciones aplicarían al principio WCAG 1.1.1 sobre Textos Alternativos de contenido no textual.